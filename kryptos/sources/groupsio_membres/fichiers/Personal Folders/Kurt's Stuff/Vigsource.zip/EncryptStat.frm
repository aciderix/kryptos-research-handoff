VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "Comdlg32.OCX"
Begin VB.Form EncryptStat 
   Caption         =   "Encrypted File Statistics"
   ClientHeight    =   3945
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   8160
   LinkTopic       =   "Form1"
   ScaleHeight     =   3945
   ScaleWidth      =   8160
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton btnModPad 
      Caption         =   "Rolling Pad"
      Height          =   375
      Left            =   6840
      TabIndex        =   11
      Top             =   0
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.CommandButton btnPolyAlpha 
      Caption         =   "Polyalpha"
      Height          =   375
      Left            =   5640
      TabIndex        =   10
      Top             =   480
      Width           =   1095
   End
   Begin VB.CommandButton btnIC 
      Caption         =   "IC Calculations"
      Height          =   375
      Left            =   4080
      TabIndex        =   9
      Top             =   480
      Width           =   1455
   End
   Begin VB.TextBox txtResults 
      BeginProperty Font 
         Name            =   "Fixedsys"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2415
      Left            =   3960
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   7
      Top             =   1320
      Width           =   3975
   End
   Begin VB.CommandButton btnStat 
      Caption         =   " Single Alphabet Frequencies"
      Height          =   375
      Left            =   4080
      TabIndex        =   6
      Top             =   0
      Width           =   2655
   End
   Begin VB.TextBox txtStatFile 
      Height          =   375
      Left            =   1920
      TabIndex        =   5
      Top             =   480
      Width           =   1935
   End
   Begin VB.TextBox txtFileCont 
      Height          =   2295
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   3
      Top             =   1320
      Width           =   3735
   End
   Begin VB.TextBox txtFileName 
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   1695
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   120
      Top             =   3360
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
      Filter          =   "*.txt"
   End
   Begin VB.Label lbl 
      Caption         =   "Statistics"
      Height          =   255
      Index           =   3
      Left            =   4080
      TabIndex        =   8
      Top             =   960
      Width           =   1695
   End
   Begin VB.Label lbl 
      Caption         =   "Statistics File Name"
      Height          =   255
      Index           =   2
      Left            =   2040
      TabIndex        =   4
      Top             =   120
      Width           =   1695
   End
   Begin VB.Label lbl 
      Caption         =   "File Contents"
      Height          =   255
      Index           =   1
      Left            =   120
      TabIndex        =   2
      Top             =   960
      Width           =   1695
   End
   Begin VB.Label lbl 
      Caption         =   "Encrypted File Name"
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1695
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuFileNew 
         Caption         =   "New Encrypted File"
      End
      Begin VB.Menu mnuSetStat 
         Caption         =   "Set Statistic File"
      End
      Begin VB.Menu mnuFileSave 
         Caption         =   "Save Statistics"
      End
      Begin VB.Menu mnuQuit 
         Caption         =   "Quit"
      End
   End
   Begin VB.Menu mnuStat 
      Caption         =   "Stats"
      Begin VB.Menu mnuStatExport 
         Caption         =   "Export"
      End
   End
   Begin VB.Menu mnuMain 
      Caption         =   "Main Menu"
   End
End
Attribute VB_Name = "EncryptStat"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public fnEncrypt, fnSolut, fnFreq As String
Public txtEncrypt, txtSolut, temp As String
Dim intTable(26, 26) As Integer
Const strAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


Private Sub btnIC_Click()
Dim x, y, n As Integer
Dim IC As Double
'Dim test As String
n = Len(txtEncrypt)
txtResults.Text = ""
Call cleartable
For x = 2 To 24
For y = x + 1 To n
If Mid(txtEncrypt, y - x, 1) = Mid(txtEncrypt, y, 1) Then intTable(1, x) = intTable(1, x) + 1
Next y
Next x
txtResults.Text = "IC results" & vbCrLf
txtResults.Text = txtResults.Text & " KL  IC" & vbCrLf
For x = 2 To 24
IC = intTable(1, x) / (n - x)
txtResults.Text = txtResults.Text & " " & x & "  " & Format(IC, "#.####")
If IC > 0.065 Then txtResults.Text = txtResults.Text & "**" & vbCrLf Else txtResults.Text = txtResults.Text & vbCrLf
Next x
'save results
If fnSolut = "" Then GoTo skipper3
Open fnSolut For Append As #3
Print #3, txtResults.Text
Close #3
skipper3:
End Sub

Private Sub btnModPad_Click()
Dim temp As String
Dim L1, L2, x, y, shift As Integer
'temp = InputBox("Input initial Shift.")
'shift = Int(Val(temp))
temp = ""
'going to try brute force
For y = 1 To 26
shift = y
For x = 1 To Len(txtEncrypt)
L1 = Asc(Mid(txtEncrypt, x, 1)) - 65
L2 = (L1 + shift) Mod 26
temp = temp & Chr(L2 + 65)
shift = L2
Next x
'test for matching frequencies
End Sub

Private Sub btnPolyAlpha_Click()
Dim x, y As Integer
Dim L, Letter As String
Call cleartable
L = InputBox("Input length of key")
For x = 1 To Len(txtEncrypt)
Letter = Mid(txtEncrypt, x, 1)
'need an error check
If Asc(Letter) < 64 Or Asc(Letter) > 90 Then GoTo skipper4
intTable(Asc(Letter) - 64, x Mod Val(L)) = intTable(Asc(Letter) - 64, x Mod Val(L)) + 1
skipper4:
Next x
'rearrange the 0 column to 7
For x = 1 To 26
intTable(x, Val(L)) = intTable(x, 0)
intTable(x, 0) = 0
Next x
'clear display
txtResults.Text = ""
txtResults.Text = "Polyalphabetic results" & vbCrLf
txtResults.Text = txtResults.Text & "Key Length = " & L & vbCrLf
txtResults.Text = txtResults.Text & "   "
For x = 1 To Val(L)
txtResults.Text = txtResults.Text & "   "
Next x
txtResults.Text = txtResults.Text & vbCrLf
For y = 1 To 26
txtResults.Text = txtResults.Text & " " & Chr(y + 64) & "  "
For x = 1 To Val(L)
txtResults.Text = txtResults.Text & intTable(y, x) & "  "
Next x
txtResults.Text = txtResults.Text & vbCrLf
Next y
'Save Results in file
If fnSolut = "" Then GoTo skipper5
Open fnSolut For Append As #5
Print #5, txtResults.Text
Close #5
skipper5:
End Sub

Private Sub btnStat_Click()
Dim x, y As Integer
Dim temp As String
Dim freq As Long
Call cleartable
'fill the table with freq
Open fnFreq For Input As #6
For y = 1 To 26
Line Input #6, temp
intTable(0, y) = Int(Val(temp))
Next y
Close #6
'fill the table with the count
For x = 1 To Len(txtEncrypt)
'Just in case of non-Alphabet characters
If Asc(Mid(txtEncrypt, x, 1)) < 64 Or Asc(Mid(txtEncrypt, x, 1)) > 96 Then GoTo skipper:
intTable(1, Asc(Mid(txtEncrypt, x, 1)) - 64) = intTable(1, Asc(Mid(txtEncrypt, x, 1)) - 64) + 1
skipper:
Next x
'Display results
txtResults.Text = ""
txtResults.Text = "Single Alphabet Frequencies" & vbCrLf
txtResults.Text = txtResults.Text & "LTR  Freq" & vbCrLf
For x = 1 To 26
freq = (intTable(1, x) / Len(txtEncrypt)) * 1000
txtResults.Text = txtResults.Text & " " & Chr(64 + x) & "    " & freq & vbCrLf
Next x
'Save Results in file
If fnSolut = "" Then GoTo skipper2
Open fnSolut For Append As #2
Print #2, txtResults.Text
Close #2
skipper2:
End Sub

Private Sub Form_Load()
fnEncrypt = ""
fnSolut = ""
fnFreq = "EngLtrFreq.txt"
End Sub

Private Sub mnuFileNew_Click()
On Error GoTo cancel
CommonDialog1.ShowOpen
fnEncrypt = CommonDialog1.FileName
txtFileName.Text = fnEncrypt
'display file contents in window
'open the file to read
txtFileCont.Text = ""
txtEncrypt = ""
Open fnEncrypt For Input As #1
Do Until EOF(1)
Input #1, temp
txtEncrypt = txtEncrypt & temp
Loop
Close #1
'now show off the file in the content window
txtEncrypt = UCase(txtEncrypt)
txtFileCont.Text = txtEncrypt
cancel:
End Sub

Private Sub mnuMain_Click()
Main.Show
Me.Hide
End Sub

Private Sub mnuQuit_Click()
End
End Sub

Private Sub mnuSetStat_Click()
On Error GoTo cancel
CommonDialog1.ShowOpen
fnSolut = CommonDialog1.FileName
txtStatFile.Text = fnSolut
cancel:
End Sub

Private Sub cleartable()
Dim x, y As Integer
'clear the table
For x = 1 To 26
For y = 1 To 26
intTable(x, y) = 0
Next y
Next x
End Sub
