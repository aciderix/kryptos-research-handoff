VERSION 5.00
Begin VB.Form Main 
   ClientHeight    =   3090
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   2595
   LinkTopic       =   "Form1"
   ScaleHeight     =   3090
   ScaleWidth      =   2595
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Quit"
      Height          =   495
      Index           =   3
      Left            =   480
      TabIndex        =   3
      Top             =   2040
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Offset Testing"
      Height          =   495
      Index           =   2
      Left            =   480
      TabIndex        =   2
      Top             =   1440
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Vigenerre"
      Height          =   495
      Index           =   1
      Left            =   480
      TabIndex        =   1
      Top             =   840
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "File Statistics"
      Height          =   495
      Index           =   0
      Left            =   480
      TabIndex        =   0
      Top             =   240
      Width           =   1335
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click(Index As Integer)
Select Case Index
Case 0
EncryptStat.Show
Me.Hide
Case 1
Vignerre.Show
Me.Hide
Case 2
offset.Show
Me.Hide
Case 3
End
End Select
End Sub
