VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "Comdlg32.OCX"
Begin VB.Form Vignerre 
   Caption         =   "Vignerre"
   ClientHeight    =   4515
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   8400
   LinkTopic       =   "Form1"
   ScaleHeight     =   4515
   ScaleWidth      =   8400
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Clean File"
      Height          =   375
      Left            =   3240
      TabIndex        =   18
      Top             =   3840
      Width           =   1335
   End
   Begin VB.CommandButton btnEncrypt 
      Caption         =   "Encrypt"
      Height          =   375
      Left            =   3240
      TabIndex        =   17
      Top             =   3360
      Width           =   1335
   End
   Begin VB.Frame Frame1 
      Caption         =   "Method"
      Height          =   855
      Left            =   3240
      TabIndex        =   12
      Top             =   2400
      Width           =   1335
      Begin VB.OptionButton optVigenere 
         Caption         =   "Option2"
         Height          =   195
         Left            =   120
         TabIndex        =   14
         Top             =   480
         Width           =   255
      End
      Begin VB.OptionButton optCartesian 
         Caption         =   "Option1"
         Height          =   195
         Left            =   120
         TabIndex        =   13
         Top             =   240
         Value           =   -1  'True
         Width           =   255
      End
      Begin VB.Label Label3 
         Caption         =   "Vigenere"
         Height          =   255
         Left            =   480
         TabIndex        =   16
         Top             =   480
         Width           =   735
      End
      Begin VB.Label Label2 
         Caption         =   "Cartesian"
         Height          =   255
         Left            =   480
         TabIndex        =   15
         Top             =   240
         Width           =   735
      End
   End
   Begin VB.CommandButton btnDecrypt 
      Caption         =   "Decrypt"
      Height          =   375
      Left            =   3240
      TabIndex        =   11
      Top             =   1920
      Width           =   1335
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   3600
      Top             =   3840
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.TextBox txtFileBox 
      BeginProperty Font 
         Name            =   "Fixedsys"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3975
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   10
      Top             =   240
      Width           =   2775
   End
   Begin VB.CheckBox chkRandomKey2 
      Caption         =   "Check1"
      Height          =   255
      Left            =   4440
      TabIndex        =   8
      Top             =   1560
      Width           =   255
   End
   Begin VB.CheckBox chkRandomKey1 
      Caption         =   "Check1"
      Height          =   255
      Left            =   4440
      TabIndex        =   6
      Top             =   600
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.TextBox txtKey2 
      Height          =   285
      Left            =   3120
      TabIndex        =   5
      Top             =   1200
      Width           =   1575
   End
   Begin VB.TextBox txtEncTable 
      BeginProperty Font 
         Name            =   "Fixedsys"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3975
      Left            =   5040
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   3
      Top             =   240
      Width           =   3255
   End
   Begin VB.TextBox txtKey1 
      Height          =   255
      Left            =   3120
      TabIndex        =   1
      Top             =   360
      Width           =   1575
   End
   Begin VB.Label lblStatus 
      Caption         =   "Status:"
      Height          =   255
      Left            =   5040
      TabIndex        =   20
      Top             =   4200
      Width           =   3375
   End
   Begin VB.Label Label4 
      Caption         =   "Message Text"
      Height          =   255
      Left            =   0
      TabIndex        =   19
      Top             =   0
      Width           =   2655
   End
   Begin VB.Label lblRandomKey 
      Caption         =   "Randomize"
      Height          =   255
      Index           =   1
      Left            =   3120
      TabIndex        =   9
      Top             =   1560
      Width           =   1335
   End
   Begin VB.Label lblRandomKey 
      Caption         =   "Randomize"
      Height          =   255
      Index           =   0
      Left            =   3120
      TabIndex        =   7
      Top             =   600
      Visible         =   0   'False
      Width           =   1335
   End
   Begin VB.Label key2label 
      Alignment       =   2  'Center
      Caption         =   "Second Key"
      Height          =   255
      Left            =   3120
      TabIndex        =   4
      Top             =   960
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "Results Table"
      Height          =   255
      Left            =   5040
      TabIndex        =   2
      Top             =   0
      Width           =   3375
   End
   Begin VB.Label Key1Label 
      Alignment       =   2  'Center
      Caption         =   "First Key"
      Height          =   255
      Left            =   3120
      TabIndex        =   0
      Top             =   120
      Width           =   1575
   End
   Begin VB.Menu mnuFile 
      Caption         =   "File"
      Begin VB.Menu mnuSave 
         Caption         =   "Save"
         Begin VB.Menu mnuSaveTable 
            Caption         =   "Save Encryption Table"
         End
         Begin VB.Menu mnuSaveResults 
            Caption         =   "Save Results"
         End
      End
      Begin VB.Menu mnuNew 
         Caption         =   "New"
         Begin VB.Menu mnuNewMsgFile 
            Caption         =   "New Message File"
         End
      End
   End
   Begin VB.Menu mnuStat 
      Caption         =   "Statistics"
      Begin VB.Menu mnuStatRun 
         Caption         =   "Run Stats on text File"
      End
   End
   Begin VB.Menu mnuMain 
      Caption         =   "Main Menu"
   End
End
Attribute VB_Name = "Vignerre"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const strAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
Dim txtEncrypt, txtDecrypt, fnEncrypt, fnDecrypt As String
Dim lkey1, lkey2 As Integer

Private Sub btnDecrypt_Click()
Dim method As Integer, test As Double, temp As String
Dim x, threshhold As Integer
Dim strLock As String
Dim strPastHits(10) As String

lblStatus.Caption = "Status: Decrypting..."
If optCartesian = True Then method = 0
If optVigenere = True Then method = 1
txtKey1.Text = UCase(txtKey1.Text)
txtKey2.Text = UCase(txtKey2.Text)
txtFileBox.Text = UCase(txtFileBox.Text)
Select Case chkRandomKey2.Value
Case 0
txtDecrypt = VDecrypt(txtKey1.Text, txtKey2.Text, txtFileBox.Text, method)
txtEncTable.Text = txtDecrypt
test = EnglishDetection(txtEncTable.Text)
If test > 20 Then lblStatus.Caption = "Status:  English = True" & Str(test) Else lblStatus.Caption = "Status:  English = False" & Str(test)
Case 1
'set the strLock to all 0's
Open fnDecrypt For Output As #2
For x = 1 To lkey2
strLock = strLock & "0"
Next
threshhold = 20
For x = 1 To 10: strPastHits(x) = "": Next x
Do While test < 100
    txtDecrypt = VDecrypt(txtKey1.Text, txtKey2.Text, txtFileBox.Text, method)
    temp = txtDecrypt
    test = EnglishDetection(temp)
    If test > threshhold Then
        strPastHits(0) = txtKey2.Text: For x = 10 To 1 Step -1: strPastHits(x) = strPastHits(x - 1): Next x
        Write #2, txtEncTable.Text
        txtEncTable.Text = txtKey1.Text & vbCrLf & txtKey2.Text & vbCrLf & test & vbCrLf & txtDecrypt & vbCrLf
        If strPastHits(2) <> "" Then strLock = LockTest(strPastHits(1), strPastHits(2))
        txtEncTable.Text = txtEncTable.Text & strLock & vbCrLf
        threshhold = threshhold + 3
        End If
    lblStatus.Caption = "Status:  Decrypting ... " & test
    txtKey2.Text = IncKey(txtKey2.Text, strLock)
    Loop
End Select
lblStatus.Caption = "Status:  Finished"
End Sub
Public Function LockTest(PastHit As String, currentHit As String) As String
Dim x, y As Integer
For x = 1 To Len(currentHit)
If Mid(PastHit, x, 1) <> Mid(currentHit, x, 1) Then y = x
Next x
LockTest = ""
For x = 1 To y
LockTest = LockTest & "0"
Next x
For x = y + 1 To Len(PastHit)
LockTest = LockTest & "1"
Next x
skipout:
If PastHit = currentHit Then For x = 1 To Len(currentHit): LockTest = LockTest & "0": Next x
End Function

Private Sub btnEncrypt_Click()
Dim method As Integer, test As Double, temp As String
Dim x As Integer

lblStatus.Caption = "Status: Encrypting..."
If optCartesian = True Then method = 0
If optVigenere = True Then method = 1
txtKey1.Text = UCase(txtKey1.Text)
txtKey2.Text = UCase(txtKey2.Text)
txtFileBox.Text = UCase(txtFileBox.Text)
txtDecrypt = VEncrypt(txtKey1.Text, txtKey2.Text, txtFileBox.Text, method)
txtEncTable.Text = txtDecrypt
End Sub

Private Sub chkRandomKey2_Click()
Dim temp As String, x As Integer
Select Case chkRandomKey2.Value
Case 0
txtKey2.Enabled = True
Case 1
txtKey2.Enabled = False
temp = InputBox("Length of key")
lkey2 = Val(temp)
txtKey2.Text = ""
For x = 1 To lkey2
txtKey2.Text = txtKey2.Text & "A"
Next x
End Select
End Sub

Private Sub Command1_Click()
Dim temp As String, x As Integer
temp = ""
txtFileBox.Text = UCase(txtFileBox.Text)
For x = 1 To Len(txtFileBox.Text)
If Asc(Mid(txtFileBox.Text, x, 1)) > 64 And Asc(Mid(txtFileBox.Text, x, 1)) < 91 Then temp = temp & Mid(txtFileBox.Text, x, 1)
Next x
txtFileBox.Text = temp
End Sub


Private Sub mnuMain_Click()
Main.Show
Me.Hide
End Sub

Private Sub mnuNewMsgFile_Click()
Dim temp As String
On Error GoTo cancel
CommonDialog1.ShowOpen
fnEncrypt = CommonDialog1.FileName
Open fnEncrypt For Input As #1
Do Until EOF(1)
Input #1, temp
txtEncrypt = txtEncrypt & temp
Loop
Close #1
'now show off the file in the content window
txtEncrypt = UCase(txtEncrypt)
txtFileBox.Text = txtEncrypt
cancel:
End Sub

Private Sub mnuSaveResults_Click()
On Error GoTo cancel
CommonDialog1.ShowOpen
fnDecrypt = CommonDialog1.FileName
Open fnDecrypt For Output As #3
Write #3, txtEncTable.Text
Close #3
cancel:
End Sub

Private Sub mnuSaveTable_Click()
On Error GoTo cancel
CommonDialog1.ShowOpen
fnDecrypt = CommonDialog1.FileName
Open fnDecrypt For Output As #2
Write #2, txtEncTable.Text
Close #2
cancel:
End Sub

Public Function VDecrypt(key1 As String, key2 As String, txtMessage As String, method As Integer) As String
Dim x, y, z, key As Integer, Letter, Reference, txtTable(26, 26) As String
VDecrypt = ""
For x = 1 To 26
txtTable(x, 0) = Mid(strAlphabet, x, 1)
txtTable(0, x) = Mid(strAlphabet, x, 1)
Next x
'First things first, Build the Table using Key 1
'Add Key 1 to the Alphabet, then strip off repeating letters.
key1 = key1 & strAlphabet
For x = 1 To Len(key1)
For y = x + 1 To Len(key1)
Letter = Mid(key1, x, 1)
If Letter = Mid(key1, y, 1) Then key1 = Left(key1, y - 1) & Right(key1, Len(key1) - y)
Next y, x
'Generate Table
For y = 1 To 26
For x = 1 To 26
txtTable(x, y) = Mid(key1, x, 1)
Next x
key1 = Right(key1, 25) & Left(key1, 1)
Next y
'OK, now we start doing some decryption
For z = 0 To Len(txtMessage) - 1
y = z Mod Len(key2) + 1 'Now y varies from 1 -> len(txtkey2.text)
'Search for Letter
Letter = Mid(txtMessage, z + 1, 1) 'Letter from Encoded Message
Reference = Mid(key2, y, 1) 'Reference Letter from Key2
'Finding the key #
For x = 1 To 26
If Reference = txtTable(x, method) Then key = x
Next x
'Finding the letter that matches within the row
For x = 1 To 26
If txtTable(x, key) = Letter Then VDecrypt = VDecrypt & txtTable(x, method)
Next x
placeholder:
Next z

End Function

Public Function EnglishDetection(Message As String) As Single
Dim word, fnDict, temp As String, Repeat, x, y, WCount, Tcount, Lcount As Integer
fnDict = "dict.txt"
Open fnDict For Input As #3
Line Input #3, temp
Repeat = Val(temp)
Tcount = 0
Lcount = 0
For x = 1 To Repeat
Line Input #3, word
WCount = 0
word = UCase(word)
For y = 1 To (Len(Message) - Len(word))
If Mid(Message, y, Len(word)) = word Then WCount = WCount + 1
Next y
Tcount = Tcount + WCount
Lcount = Lcount + WCount * Len(word)
Next x
Close #3
EnglishDetection = Lcount / Len(Message) * 100
End Function

Public Function IncKey(key As String, strLock As String) As String
Dim x, y As Integer, temp, Error As String
y = 0
For x = Len(key) To 1 Step -1
    If Mid(strLock, x, 1) = "1" Then GoTo skiploop
    If Mid(key, x, 1) = "Z" And y = 0 And x <> Len(key) Then
        key = Left(key, x - 1) & "A" & Right(key, Len(key) - x)
        GoTo skiploop
        End If
    
    If Mid(key, x, 1) = "Z" And y = 0 And x = Len(key) Then
        key = Left(key, x - 1) & "A"
        GoTo skiploop
        End If
    If y = 0 And x <> Len(key) Then
        IncKey = Left(key, x - 1) & Chr(Asc(Mid(key, x, 1)) + 1) & Right(key, Len(key) - x)
        y = y + 1
        GoTo skiploop
        End If
    If y = 0 And x = Len(key) Then
        IncKey = Left(key, x - 1) & Chr(Asc(Right(key, 1)) + 1)
        y = 1
        GoTo skiploop
        End If
skiploop:
Next x
DoEvents
End Function

Public Function VEncrypt(key1 As String, key2 As String, txtMessage As String, method As Integer) As String
Dim x, y, z, key As Integer, Letter, Reference, txtTable(26, 26) As String
VEncrypt = ""
For x = 1 To 26
txtTable(x, 0) = Mid(strAlphabet, x, 1)
txtTable(0, x) = Mid(strAlphabet, x, 1)
Next x
'First things first, Build the Table using Key 1
'Add Key 1 to the Alphabet, then strip off repeating letters.
key1 = key1 & strAlphabet
For x = 1 To Len(key1)
For y = x + 1 To Len(key1)
Letter = Mid(key1, x, 1)
If Letter = Mid(key1, y, 1) Then key1 = Left(key1, y - 1) & Right(key1, Len(key1) - y)
Next y, x
'Generate Table based on Key1
For y = 1 To 26
For x = 1 To 26
txtTable(x, y) = Mid(key1, x, 1)
Next x
key1 = Right(key1, 25) & Left(key1, 1)
Next y
'OK, now we start doing some decryption
For z = 0 To Len(txtMessage) - 1
y = z Mod Len(key2) + 1 'Now y varies from 1 -> len(txtkey2.text)
'z = letter position within the message, and y is the letter position w/i key 2

''Search for Letter
Letter = Mid(txtMessage, z + 1, 1) 'Letter from Message
Reference = Mid(key2, y, 1) 'Reference Letter from Key2
''Finding the key #
For x = 1 To 26
If Reference = txtTable(x, method) Then key = x
Next x
'Finding the letter that matches within the column
For x = 1 To 26
If txtTable(method, x) = Letter Then VEncrypt = VEncrypt & txtTable(key, x)
Next x
'placeholder:
Next z

End Function
