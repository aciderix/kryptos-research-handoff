﻿Imports System.Text.Encoding
Module CryptoFunctions
    'UNUSED IN THIS PROJECT
    'Vigenere encryption of the input (Passed as a byte array) using the keyword (Passed as a byte array).
    Function VigenereEncode(ByRef ClearText() As Byte, ByRef keyword() As Byte) As Byte()
        Dim CleartextLength As Integer = ClearText.Length - 1
        Dim CipherText(CleartextLength) As Byte

        For i As Integer = 0 To CleartextLength
            CipherText(i) = CByte(65 + (ClearText(i) + keyword(i Mod keyword.Length) - 130) Mod 26)
        Next
        Return CipherText

    End Function
    'UNUSED IN THIS PROJECT
    'Vigenere decryption of the input (Passed as a byte array) using the keyword (Also passed as a byte array).
    Function VigenereDecode(ByRef CipherText() As Byte, ByRef keyword() As Byte) As Byte()
        Dim CiphertextLength As Integer = CipherText.Length - 1
        Dim ClearText(CiphertextLength) As Byte

        For i As Integer = 0 To CiphertextLength
            ClearText(i) = CByte(65 + (CipherText(i) - (keyword(i Mod keyword.Length) + 0) + 26) Mod 26)
        Next
        Return ClearText

    End Function
    'Remove all non-alphabetic and non-caps characters from the input array.(ASCII 65 - 95 are the range of Alphabetic CAPS)
    Function RemoveIllegalElements(ByRef Input() As Byte) As Byte()
        Dim i, index As Integer
        index = 0
        Do Until index = Input.Length
            If Input(CInt(index)) < 65 Or Input(CInt(index)) > 90 Then
                For i = index To UBound(Input) - 1
                    Input(i) = Input(CInt(i + 1))
                Next i
                ReDim Preserve Input(UBound(Input) - 1)
                index -= 1
            End If
            index += 1
        Loop
        Return Input
    End Function
    'Decipher the Ciphertext with the given keyword and Indicator Key. Method A - Does not create a quagmire table so is faster than B.
    Function QuaqmireDecipher(Keyword As Byte(), IndicatorWord As Byte(), CipherText As Byte()) As Byte()
        Dim ClearText(CipherText.Length - 1), KeyedAlphabet(25) As Byte
        Dim CharIndex(25) As Integer
        Dim CipherTextLength As Integer = ClearText.Length - 1
        Dim IndicatorLength As Integer = IndicatorWord.Length
        'Add the keyword characters.
        For Each element In Keyword
            If Not KeyedAlphabet.Contains(element) Then 'If the array doesn't have the value...
                KeyedAlphabet.SetValue(element, Array.IndexOf(KeyedAlphabet, Nothing)) 'Copy the value into the 1st available empty element.
            End If
        Next
        'Then add the remaining alphabetic characters.
        For ASCIIValue As Byte = 65 To 90 'ASCII A to Z
            If Not KeyedAlphabet.Contains(ASCIIValue) Then
                KeyedAlphabet.SetValue(ASCIIValue, Array.IndexOf(KeyedAlphabet, Nothing)) '1st empty element.
            End If
            CharIndex(ASCIIValue - 65) = Array.IndexOf(KeyedAlphabet, ASCIIValue) 'Also, map the index of each character (A-Z)
        Next
        'Decipher
        For i = 0 To CipherTextLength
            ClearText(i) = KeyedAlphabet((CharIndex(CipherText(i) - 65) - CharIndex(IndicatorWord(i Mod IndicatorLength) - 65) + 26) Mod 26)
        Next

        Return ClearText
        ClearText = Nothing : KeyedAlphabet = Nothing : CharIndex = Nothing

    End Function
    'Decipher the Ciphertext with the given keyword and Indicator Key. Method B - Calls GenerateQuagmireTable so slower.
    Function QuaqmireDecipherB(Keyword As Byte(), IndicatorWord As Byte(), CipherText As Byte()) As Byte()
        Dim QuagmireTable(,) As Byte
        Dim ClearText(CipherText.Length - 1) As Byte
        Dim CipherTextLength As Integer = ClearText.Length
        Dim lines As Integer = IndicatorWord.Length
        Dim line As Integer = 1

        'Get the Quagmire table.
        QuagmireTable = GenerateQuagmireTable(Keyword, IndicatorWord)

        'Decipher the ciphertext using the Quagmire table into the Cleartext array.
        For i = 0 To CipherTextLength - 1
            For j = 0 To 25
                If CipherText(i) = QuagmireTable(line, j) Then
                    ClearText(i) = QuagmireTable(0, j) 'Cleartext = Coresponding character in the top row.
                    Exit For
                End If
            Next
            If Not line = lines Then line += 1 Else line = 1
        Next
        Return ClearText
        QuagmireTable = Nothing : ClearText = Nothing
    End Function
    'Generates a Quagmire table from the given Keyword and Indicator Keyword (Passed as byte arrays for speed)
    Function GenerateQuagmireTable(ByRef TableauKey() As Byte, ByRef IndicatorKey() As Byte) As Byte(,)
        Dim QuagmireTable(IndicatorKey.Length, 25), TempLine(25), TableauLine(25) As Byte
        Dim SplitPoint As Integer

        For Each element In TableauKey
            If Not TableauLine.Contains(element) Then 'If the array doesn't have the value...
                TableauLine.SetValue(element, Array.IndexOf(TableauLine, Nothing)) 'copy the value into the 1st empty element of the array.
            End If
        Next

        'Add the remaining alphabetic characters.
        For ASCIIValue As Byte = 65 To 90 'ASCII A to Z
            If Not TableauLine.Contains(ASCIIValue) Then
                TableauLine.SetValue(ASCIIValue, Array.IndexOf(TableauLine, Nothing))
            End If
        Next

        For x = 0 To 25
            QuagmireTable(0, x) = TableauLine(x) 'The first line is the same as the VigTable's first line.
        Next

        'Do this for each character in the indicaor key.
        'Only need to generate the rows of the vig-table that corespond to the indicator key.
        For i = 0 To IndicatorKey.Length - 1
            SplitPoint = Array.IndexOf(TableauLine, IndicatorKey(i)) 'The location to split the line.
            For j = SplitPoint To TableauLine.Count - 1
                TempLine(j - SplitPoint) = TableauLine(j)
            Next
            For j = 0 To SplitPoint - 1
                TempLine(j + 26 - SplitPoint) = TableauLine(j)
            Next
            For x = 0 To 25
                QuagmireTable(i + 1, x) = TempLine(x)
            Next
        Next

        Return QuagmireTable

        QuagmireTable = Nothing : TempLine = Nothing : TableauLine = Nothing 'Housekeeping

    End Function
    'Convert the QuagmireTable from bytes to text (When needed for display on form).
    Function QuagmireTableAsText(QuagmireTable(,) As Byte) As String
        Dim aryTableLine(25) As Byte
        Dim QuagmireTableText As String = ""
        For i = 0 To QuagmireTable.GetLength(0) - 1
            For index = 0 To QuagmireTable.GetLength(1) - 1
                aryTableLine(index) = QuagmireTable(i, index)
            Next
            QuagmireTableText = QuagmireTableText & ASCII.GetString(aryTableLine) & vbCrLf
        Next
        Return QuagmireTableText
        QuagmireTableAsText = Nothing
    End Function

End Module
