﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Kryptos Solver")>
<Assembly: AssemblyDescription("A general Quagmire 3 solver optimised for Kryptos.")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("Kryptos Solver")>
<Assembly: AssemblyCopyright("Copyright ©  2015 P.McDonagh")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("27a6e40a-69d3-4bb7-aa93-bde10232bbfc")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
