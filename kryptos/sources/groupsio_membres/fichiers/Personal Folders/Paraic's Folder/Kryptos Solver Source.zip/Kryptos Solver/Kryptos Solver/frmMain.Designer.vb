﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnDecode = New System.Windows.Forms.Button()
        Me.tbCipherText = New System.Windows.Forms.TextBox()
        Me.tbOutput = New System.Windows.Forms.TextBox()
        Me.tbTableauKey = New System.Windows.Forms.TextBox()
        Me.lblKey = New System.Windows.Forms.Label()
        Me.lblClearText = New System.Windows.Forms.Label()
        Me.lblCipherText = New System.Windows.Forms.Label()
        Me.tbQuagTable = New System.Windows.Forms.TextBox()
        Me.lblIndicator = New System.Windows.Forms.Label()
        Me.tbIndicatorKey = New System.Windows.Forms.TextBox()
        Me.lblTable = New System.Windows.Forms.Label()
        Me.cbShowTable = New System.Windows.Forms.CheckBox()
        Me.tbCrib = New System.Windows.Forms.TextBox()
        Me.lblCrib = New System.Windows.Forms.Label()
        Me.nudLocation = New System.Windows.Forms.NumericUpDown()
        Me.lblCribStart = New System.Windows.Forms.Label()
        Me.lblTablesTested = New System.Windows.Forms.Label()
        Me.lblKeysTest = New System.Windows.Forms.Label()
        Me.cbAuto = New System.Windows.Forms.CheckBox()
        Me.lblAuto = New System.Windows.Forms.Label()
        Me.tbClearText = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.nudLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDecode
        '
        Me.btnDecode.Location = New System.Drawing.Point(287, 391)
        Me.btnDecode.Name = "btnDecode"
        Me.btnDecode.Size = New System.Drawing.Size(75, 23)
        Me.btnDecode.TabIndex = 2
        Me.btnDecode.Text = "Decode"
        Me.btnDecode.UseVisualStyleBackColor = True
        '
        'tbCipherText
        '
        Me.tbCipherText.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbCipherText.Location = New System.Drawing.Point(12, 23)
        Me.tbCipherText.Multiline = True
        Me.tbCipherText.Name = "tbCipherText"
        Me.tbCipherText.Size = New System.Drawing.Size(244, 58)
        Me.tbCipherText.TabIndex = 4
        Me.tbCipherText.Text = "OBKRUOXOGHULBSOLIFBBWFLRVQQPRNGKSSOTWTQSJQSSEKZZWATJKLUDIAWINFBNYPVTTMZFPKWGDKZXT" &
    "JCDIGKUHUAUEKCAR"
        '
        'tbOutput
        '
        Me.tbOutput.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbOutput.Location = New System.Drawing.Point(10, 178)
        Me.tbOutput.Multiline = True
        Me.tbOutput.Name = "tbOutput"
        Me.tbOutput.ReadOnly = True
        Me.tbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbOutput.Size = New System.Drawing.Size(260, 85)
        Me.tbOutput.TabIndex = 5
        '
        'tbTableauKey
        '
        Me.tbTableauKey.Location = New System.Drawing.Point(14, 286)
        Me.tbTableauKey.Name = "tbTableauKey"
        Me.tbTableauKey.ReadOnly = True
        Me.tbTableauKey.Size = New System.Drawing.Size(236, 20)
        Me.tbTableauKey.TabIndex = 6
        '
        'lblKey
        '
        Me.lblKey.AutoSize = True
        Me.lblKey.Location = New System.Drawing.Point(10, 270)
        Me.lblKey.Name = "lblKey"
        Me.lblKey.Size = New System.Drawing.Size(70, 13)
        Me.lblKey.TabIndex = 7
        Me.lblKey.Text = "Tableau Key:"
        '
        'lblClearText
        '
        Me.lblClearText.AutoSize = True
        Me.lblClearText.Location = New System.Drawing.Point(10, 162)
        Me.lblClearText.Name = "lblClearText"
        Me.lblClearText.Size = New System.Drawing.Size(84, 13)
        Me.lblClearText.TabIndex = 8
        Me.lblClearText.Text = "Output Window:"
        '
        'lblCipherText
        '
        Me.lblCipherText.AutoSize = True
        Me.lblCipherText.Location = New System.Drawing.Point(15, 7)
        Me.lblCipherText.Name = "lblCipherText"
        Me.lblCipherText.Size = New System.Drawing.Size(64, 13)
        Me.lblCipherText.TabIndex = 9
        Me.lblCipherText.Text = "Cipher Text:"
        '
        'tbQuagTable
        '
        Me.tbQuagTable.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbQuagTable.Location = New System.Drawing.Point(284, 23)
        Me.tbQuagTable.Multiline = True
        Me.tbQuagTable.Name = "tbQuagTable"
        Me.tbQuagTable.ReadOnly = True
        Me.tbQuagTable.Size = New System.Drawing.Size(194, 297)
        Me.tbQuagTable.TabIndex = 12
        '
        'lblIndicator
        '
        Me.lblIndicator.AutoSize = True
        Me.lblIndicator.Location = New System.Drawing.Point(10, 315)
        Me.lblIndicator.Name = "lblIndicator"
        Me.lblIndicator.Size = New System.Drawing.Size(72, 13)
        Me.lblIndicator.TabIndex = 14
        Me.lblIndicator.Text = "Indicator Key:"
        '
        'tbIndicatorKey
        '
        Me.tbIndicatorKey.Location = New System.Drawing.Point(13, 331)
        Me.tbIndicatorKey.Name = "tbIndicatorKey"
        Me.tbIndicatorKey.ReadOnly = True
        Me.tbIndicatorKey.Size = New System.Drawing.Size(236, 20)
        Me.tbIndicatorKey.TabIndex = 13
        '
        'lblTable
        '
        Me.lblTable.AutoSize = True
        Me.lblTable.Location = New System.Drawing.Point(284, 6)
        Me.lblTable.Name = "lblTable"
        Me.lblTable.Size = New System.Drawing.Size(37, 13)
        Me.lblTable.TabIndex = 15
        Me.lblTable.Text = "Table:"
        '
        'cbShowTable
        '
        Me.cbShowTable.AutoSize = True
        Me.cbShowTable.Location = New System.Drawing.Point(386, 395)
        Me.cbShowTable.Name = "cbShowTable"
        Me.cbShowTable.Size = New System.Drawing.Size(90, 17)
        Me.cbShowTable.TabIndex = 16
        Me.cbShowTable.Text = "Take a peak!"
        Me.cbShowTable.UseVisualStyleBackColor = True
        '
        'tbCrib
        '
        Me.tbCrib.Location = New System.Drawing.Point(13, 391)
        Me.tbCrib.Name = "tbCrib"
        Me.tbCrib.Size = New System.Drawing.Size(100, 20)
        Me.tbCrib.TabIndex = 17
        Me.tbCrib.Text = "BERLINCLOCK"
        '
        'lblCrib
        '
        Me.lblCrib.AutoSize = True
        Me.lblCrib.Location = New System.Drawing.Point(12, 373)
        Me.lblCrib.Name = "lblCrib"
        Me.lblCrib.Size = New System.Drawing.Size(28, 13)
        Me.lblCrib.TabIndex = 18
        Me.lblCrib.Text = "Crib:"
        '
        'nudLocation
        '
        Me.nudLocation.Location = New System.Drawing.Point(137, 391)
        Me.nudLocation.Maximum = New Decimal(New Integer() {999, 0, 0, 0})
        Me.nudLocation.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLocation.Name = "nudLocation"
        Me.nudLocation.Size = New System.Drawing.Size(40, 20)
        Me.nudLocation.TabIndex = 19
        Me.nudLocation.Value = New Decimal(New Integer() {64, 0, 0, 0})
        '
        'lblCribStart
        '
        Me.lblCribStart.AutoSize = True
        Me.lblCribStart.Location = New System.Drawing.Point(134, 373)
        Me.lblCribStart.Name = "lblCribStart"
        Me.lblCribStart.Size = New System.Drawing.Size(97, 13)
        Me.lblCribStart.TabIndex = 21
        Me.lblCribStart.Text = "Crib Start Location:"
        '
        'lblTablesTested
        '
        Me.lblTablesTested.AutoSize = True
        Me.lblTablesTested.Location = New System.Drawing.Point(88, 354)
        Me.lblTablesTested.Name = "lblTablesTested"
        Me.lblTablesTested.Size = New System.Drawing.Size(13, 13)
        Me.lblTablesTested.TabIndex = 22
        Me.lblTablesTested.Text = "0"
        '
        'lblKeysTest
        '
        Me.lblKeysTest.AutoSize = True
        Me.lblKeysTest.Location = New System.Drawing.Point(10, 354)
        Me.lblKeysTest.Name = "lblKeysTest"
        Me.lblKeysTest.Size = New System.Drawing.Size(78, 13)
        Me.lblKeysTest.TabIndex = 23
        Me.lblKeysTest.Text = "Tables Tested:"
        '
        'cbAuto
        '
        Me.cbAuto.AutoSize = True
        Me.cbAuto.Checked = True
        Me.cbAuto.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbAuto.Location = New System.Drawing.Point(260, 289)
        Me.cbAuto.Name = "cbAuto"
        Me.cbAuto.Size = New System.Drawing.Size(15, 14)
        Me.cbAuto.TabIndex = 24
        Me.cbAuto.UseVisualStyleBackColor = True
        '
        'lblAuto
        '
        Me.lblAuto.AutoSize = True
        Me.lblAuto.Location = New System.Drawing.Point(253, 270)
        Me.lblAuto.Name = "lblAuto"
        Me.lblAuto.Size = New System.Drawing.Size(29, 13)
        Me.lblAuto.TabIndex = 25
        Me.lblAuto.Text = "Auto"
        '
        'tbClearText
        '
        Me.tbClearText.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbClearText.Location = New System.Drawing.Point(10, 101)
        Me.tbClearText.Multiline = True
        Me.tbClearText.Name = "tbClearText"
        Me.tbClearText.ReadOnly = True
        Me.tbClearText.Size = New System.Drawing.Size(240, 54)
        Me.tbClearText.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Clear Text:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 426)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tbClearText)
        Me.Controls.Add(Me.lblAuto)
        Me.Controls.Add(Me.cbAuto)
        Me.Controls.Add(Me.lblKeysTest)
        Me.Controls.Add(Me.lblTablesTested)
        Me.Controls.Add(Me.lblCribStart)
        Me.Controls.Add(Me.nudLocation)
        Me.Controls.Add(Me.lblCrib)
        Me.Controls.Add(Me.tbCrib)
        Me.Controls.Add(Me.cbShowTable)
        Me.Controls.Add(Me.lblTable)
        Me.Controls.Add(Me.lblIndicator)
        Me.Controls.Add(Me.tbIndicatorKey)
        Me.Controls.Add(Me.tbQuagTable)
        Me.Controls.Add(Me.lblCipherText)
        Me.Controls.Add(Me.lblClearText)
        Me.Controls.Add(Me.lblKey)
        Me.Controls.Add(Me.tbTableauKey)
        Me.Controls.Add(Me.tbOutput)
        Me.Controls.Add(Me.tbCipherText)
        Me.Controls.Add(Me.btnDecode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.Text = "Quagmire Decoder"
        CType(Me.nudLocation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnDecode As Button
    Friend WithEvents tbCipherText As TextBox
    Friend WithEvents tbOutput As TextBox
    Friend WithEvents tbTableauKey As TextBox
    Friend WithEvents lblKey As Label
    Friend WithEvents lblClearText As Label
    Friend WithEvents lblCipherText As Label
    Friend WithEvents tbQuagTable As TextBox
    Friend WithEvents lblIndicator As Label
    Friend WithEvents tbIndicatorKey As TextBox
    Friend WithEvents lblTable As Label
    Friend WithEvents cbShowTable As CheckBox
    Friend WithEvents tbCrib As TextBox
    Friend WithEvents lblCrib As Label
    Friend WithEvents nudLocation As NumericUpDown
    Friend WithEvents lblCribStart As Label
    Friend WithEvents lblTablesTested As Label
    Friend WithEvents lblKeysTest As Label
    Friend WithEvents cbAuto As CheckBox
    Friend WithEvents lblAuto As Label
    Friend WithEvents tbClearText As TextBox
    Friend WithEvents Label1 As Label
End Class
