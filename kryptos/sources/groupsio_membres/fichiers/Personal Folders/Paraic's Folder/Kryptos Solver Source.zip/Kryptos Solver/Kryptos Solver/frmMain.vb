﻿Imports System.Text.Encoding
Imports System.Threading
Public Class frmMain
    Private DecipherThread As Thread
    Private listWordsInBytes As New List(Of Byte())
    Private FoundFlag As Boolean
    'Start the process when the Decode button is pressed.
    Private Sub btnDecode_Click(sender As Object, e As EventArgs) Handles btnDecode.Click
        'Run the decipher algorithm as a seperate thread. (To maintain GUI Responsiveness)
        DecipherThread = New Thread(AddressOf threadDecipher)
        CheckForIllegalCrossThreadCalls = False 'Needed to prevent crossthread call exceptions when accessing form control values.
        If Not DecipherThread.IsAlive Then 'Only execute if the thread if not already running.
            Try
                DecipherThread.Start()
            Catch ex As Exception
                MsgBox("An unknown error occurred." & vbLf & "Use Caps for Crib and Ciphertext.")
            End Try
        End If
    End Sub

    Sub threadDecipher()
        Dim TablesTested As ULong = 0
        Dim WordListLength = listWordsInBytes.Count

        lblTablesTested.Text = CType(TablesTested, String)
        tbCipherText.Text = ASCII.GetString(RemoveIllegalElements(ASCII.GetBytes(tbCipherText.Text))) 'Clean ciphertext.
        tbOutput.Clear() : tbIndicatorKey.Clear() : tbQuagTable.Clear()
        btnDecode.Enabled = False : cbAuto.Enabled = False
        FoundFlag = False
        tbCrib.Text = ASCII.GetString(RemoveIllegalElements(ASCII.GetBytes(tbCrib.Text)))
        nudLocation.Maximum = tbCipherText.Text.Length - tbCrib.Text.Length

        If tbCipherText.Text.Length > 0 And tbCrib.Text.Length > 0 Then 'Only Run if the conditions are met (All caps crib and cipher text).

            Select Case cbAuto.Checked
                Case True
                    For Each Keyword In listWordsInBytes
                        tbTableauKey.Text = ASCII.GetString(Keyword) 'Show the current key on the form.
                        Decipher(Keyword)
                        lblTablesTested.Text = TablesTested.ToString("N0") 'Format number with commas and put in Keys tested label.
                        TablesTested += CType(WordListLength, ULong) 'Increment the counter by the number of words in the dictionary.
                    Next

                Case False
                    If tbTableauKey.Text.Length > 0 Then
                        tbTableauKey.Text = ASCII.GetString(RemoveIllegalElements(ASCII.GetBytes(tbTableauKey.Text)))
                        Dim Keyword() As Byte = ASCII.GetBytes(tbTableauKey.Text)
                        Decipher(Keyword)
                        lblTablesTested.Text = TablesTested.ToString("N0")
                        TablesTested += CType(WordListLength, ULong) 'Increment the counter by the number of words in the dictionary.
                    Else
                        MsgBox("Keyword can't be empty" & vbLf & "when auto is off!")
                    End If
            End Select
            If FoundFlag = True Then MsgBox("Crib Found!") Else MsgBox("Target Crib not found!")
        Else
            MsgBox("Ciphertext or Crib" & vbLf & "can't be empty!")
        End If
        btnDecode.Enabled = True : cbAuto.Enabled = True
    End Sub
    Sub Decipher(Keyword As Byte())
        Dim Crib() As Byte = ASCII.GetBytes(tbCrib.Text)
        Dim CribLength As Integer = Crib.Length - 1
        Dim CribLocation As Integer = CInt(nudLocation.Value - 1)
        Dim TestSequence(CribLength) As Byte
        Dim CipherTextInBytes = RemoveIllegalElements(ASCII.GetBytes(tbCipherText.Text)) 'Clean ciphertext and store in byte array.
        Dim ClearTextInBytes(CipherTextInBytes.Length - 1) As Byte
        Dim CipherTextLength As Integer = ClearTextInBytes.Length

        For Each IndicatorWord In listWordsInBytes

            ClearTextInBytes = QuaqmireDecipher(Keyword, IndicatorWord, CipherTextInBytes)

            'Check if the crib is found
            Array.Copy(ClearTextInBytes, CribLocation, TestSequence, 0, CribLength + 1)
            If TestSequence.SequenceEqual(Crib) Then
                tbIndicatorKey.Text = ASCII.GetString(IndicatorWord)
                tbOutput.AppendText(tbTableauKey.Text & "," & tbIndicatorKey.Text & vbCrLf & ASCII.GetString(ClearTextInBytes) & vbCrLf & vbCrLf) 'If yes, output cleartext.
                tbQuagTable.Text = QuagmireTableAsText(GenerateQuagmireTable(Keyword, IndicatorWord))
                FoundFlag = True
            End If

            'Show table etc. if check box is ticked
            If cbShowTable.Checked Then
                tbIndicatorKey.Text = ASCII.GetString(IndicatorWord)
                tbQuagTable.Text = QuagmireTableAsText(GenerateQuagmireTable(Keyword, IndicatorWord))
                tbIndicatorKey.Clear()
                tbClearText.Text = ASCII.GetString(ClearTextInBytes)
            End If
        Next
        tbQuagTable.Clear()
        tbClearText.Clear()
    End Sub
    'Main Form Load
    Private Sub frmMain1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aryWordList() As String
        'When the main form loads, load the dictionary into a list (Of byte arrays)
        aryWordList = Split(FileIO.FileSystem.ReadAllText(Application.StartupPath & "/" & "SmallDictionary.txt"), ",")
        For i = 1 To aryWordList.Length - 1
            listWordsInBytes.Add(ASCII.GetBytes(aryWordList(i)))
        Next
        'Also only allow a sensible value to be set in the number up/down control.(Crib location).
        nudLocation.Maximum = tbCipherText.Text.Length - tbCrib.Text.Length
    End Sub
    Private Sub frmMain_Closing(sender As Object, e As EventArgs) Handles MyBase.Closing
        'End the Decipher thread on user exiting.
        If DecipherThread.IsAlive Then
            DecipherThread.Abort()
        End If
        listWordsInBytes = Nothing
        System.GC.Collect() 'Cleaning up is everyone's responsibility.
    End Sub
    'Enable/Disable Auto mode.
    Private Sub cbAuto_CheckedChanged(sender As Object, e As EventArgs) Handles cbAuto.CheckedChanged
        If cbAuto.Checked Then
            tbTableauKey.ReadOnly = True
        Else
            tbTableauKey.ReadOnly = False
        End If
    End Sub
    'Only allow a sensible crib location value.
    Private Sub tbTextBox_TextChanged(sender As Object, e As EventArgs) Handles tbCipherText.TextChanged, tbCrib.TextChanged
        nudLocation.Maximum = tbCipherText.Text.Length - tbCrib.Text.Length 'Set number up/down controlvalues.
        nudLocation.Minimum = 1
    End Sub
End Class
